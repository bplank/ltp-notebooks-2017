__author__ = "bplank"
"""
Exercise: sentiment classification with logistic regression

1) Examine the code/data.
   What is the distribution of labels in the data (how many positive/negative)?
   What vectorizer is used/how is the text represented?
2) What is a baseline the system can be compared to? Implement the baseline.
3) Add code to train and evaluate the classifier. What accuracy do you get? What is weird?
4) Add code that shows the wrongly predicted instances. Discuss with your neighbor.
"""
from collections import Counter
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
import numpy as np
import random

def load_sentiment_sentences_and_labels():
    """
    loads the movie review data
    """
    positive_sentences = [l.strip() for l in open("rt-polaritydata/rt-polarity.pos").readlines()]
    negative_sentences = [l.strip() for l in open("rt-polaritydata/rt-polarity.neg").readlines()]

    positive_labels = [1 for sentence in positive_sentences]
    negative_labels = [0 for sentence in negative_sentences]

    sentences = np.concatenate([positive_sentences,negative_sentences], axis=0)
    labels = np.concatenate([positive_labels,negative_labels],axis=0)

    ## make sure we have a label for every data instance
    assert(len(sentences)==len(labels))
    data = list(zip(sentences,labels))

    return data

def train_dev_test_split(data):
    """
    split data into train (60%), dev (20%) and test (20%)
    """
    random.seed(113) #seed


    # split data
    train_end = int(0.6 * len(data))
    dev_end = int(0.8 * len(data))

    sentences = [sentence for sentence, label in data]
    labels = [label for sentence, label in data]
    X_train, X_dev, X_test = sentences[:train_end], sentences[train_end:dev_end], sentences[dev_end:]
    y_train, y_dev, y_test = labels[:train_end], labels[train_end:dev_end], labels[dev_end:]
    assert (len(X_train) == len(y_train))
    assert (len(X_dev) == len(y_dev))
    assert (len(X_test) == len(y_test))

    return X_train, y_train, X_dev, y_dev, X_test, y_test
    

## read input data
print("load data..")
data = load_sentiment_sentences_and_labels()
X_train, y_train, X_dev, y_dev, X_test, y_test = train_dev_test_split(data)

print("#train instances: {} #dev: {} #test: {}".format(len(X_train),len(X_dev),len(X_test)))

## Q2: Add a simple baseline -- your code here

baseline_test = None
baseline_dev = None

## end your code for Q2

print("vectorize data..")
vectorizer = CountVectorizer()

classifier = Pipeline( [('vec', vectorizer),
                        ('clf', LogisticRegression())] )

print("train model..")

### Q3: Train and evaluate the classifier -- your code here

y_predicted_test = None
y_predicted_dev = None

## end your code here for Q3


###
if y_predicted_dev:
    accuracy_dev = accuracy_score(y_dev, y_predicted_dev)

    print("===== dev set ====")
    print("Baseline:   {0:.2f}".format(accuracy_score(y_dev, baseline_dev)*100))
    print("Classifier: {0:.2f}".format(accuracy_dev*100))

if y_predicted_test:
    accuracy_test = accuracy_score(y_test, y_predicted_test)

    print("===== test set ====")
    print("Baseline:   {0:.2f}".format(accuracy_score(y_test, baseline_test)*100))
    print("Classifier: {0:.2f}".format(accuracy_test*100))


### Q4: Inspect output - add your code here


## end